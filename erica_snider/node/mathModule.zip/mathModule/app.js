var mathlib = require('./mathlib')();

console.log(mathlib.add(4,5));
console.log(mathlib.multiply(4,5));
console.log(mathlib.square(5));
console.log(mathlib.random(7,21));
